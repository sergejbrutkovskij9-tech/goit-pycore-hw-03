import sys
from pathlib import Path
from colorama import Fore, init

init(autoreset=True)


def list_files(startpath, indent=0):
    print(Fore.BLUE + " " * 4 * indent + f"{startpath.name}/")

    for item in startpath.iterdir():
        if item.is_dir():
            list_files(item, indent + 1)
        else:
            print(Fore.GREEN + " " * 4 * (indent + 1) + item.name)


if __name__ == "__main__":

    # якщо аргумент є — беремо його, якщо ні — поточна папка
    if len(sys.argv) > 1:
        directory_path = Path(sys.argv[1])
    else:
        directory_path = Path.cwd()

    if not directory_path.exists() or not directory_path.is_dir():
        print(f"Директорія {directory_path} не існує або не є директорією.")
        sys.exit(1)

    list_files(directory_path)
        
    if not target_path.is_dir():
        print(f"{Fore.RED}Помилка: Шлях '{target_path}' не є директорією.{Style.RESET_ALL}")
        sys.exit(1)
        
    # Вивід кореневої папки
    print(f"{Fore.CYAN}{Style.BRIGHT}📦 {target_path.name}{Style.RESET_ALL}")
    
    # Запуск рекурсивного обходу
    print_directory_structure(target_path)

if __name__ == "__main__":
    main()
